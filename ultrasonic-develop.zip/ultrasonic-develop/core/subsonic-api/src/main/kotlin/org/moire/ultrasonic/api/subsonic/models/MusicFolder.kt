package org.moire.ultrasonic.api.subsonic.models

data class MusicFolder(val id: String = "", val name: String = "")
