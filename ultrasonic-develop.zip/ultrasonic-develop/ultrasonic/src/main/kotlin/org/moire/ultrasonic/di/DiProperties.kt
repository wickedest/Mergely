package org.moire.ultrasonic.di

object DiProperties {
    const val APP_CONTEXT = "app_context"
}
