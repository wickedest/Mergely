/* Dummy function for programs that don't use menuutil.c */

#include "mix3.h"

int menu_getuserpass(BUFFER *b, int i)
{
  return -1;
}

void cl(int y, int x)
{}

int download_stats(char *sourcename)
{
    return -1;
}
